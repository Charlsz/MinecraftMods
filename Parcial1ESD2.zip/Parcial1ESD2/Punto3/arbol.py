class Nodo:
    def __init__(self, valor):
        self.valor = valor
        self.izquierda = None
        self.derecha = None

class ArbolBinario:
    def __init__(self, raiz):
        self.raiz = raiz
#Los metodos de recorrido fueron explicados en clase y posteriormente escritos en mi libreta
#Recomendación: escriba todo lo que vea en el tablero.
def preorden(nodo):
    if nodo:
        print(nodo.valor)
        preorden(nodo.izquierda)
        preorden(nodo.derecha)

def postorden(nodo):
    if nodo:
        postorden(nodo.izquierda)
        postorden(nodo.derecha)
        print(nodo.valor)

def inorder(nodo):
    if nodo:
        inorder(nodo.izquierda)
        print(nodo.valor)
        inorder(nodo.derecha)

arbol = ArbolBinario(Nodo(10))
arbol.raiz.izquierda = Nodo(26)
arbol.raiz.derecha = Nodo(7)
arbol.raiz.izquierda.izquierda = Nodo(2)
arbol.raiz.izquierda.derecha = Nodo(38)
arbol.raiz.derecha.derecha = Nodo(107)
arbol.raiz.izquierda.izquierda.izquierda = Nodo(14)
arbol.raiz.izquierda.izquierda.derecha = Nodo(66)
arbol.raiz.derecha.derecha.izquierda = Nodo(4)
arbol.raiz.derecha.derecha.derecha = Nodo(5)
arbol.raiz.derecha.derecha.izquierda.izquierda = Nodo(12)
arbol.raiz.derecha.derecha.derecha.derecha = Nodo(4)
arbol.raiz.derecha.derecha.derecha.derecha.izquierda = Nodo(5)

print("preorden:")
preorden(arbol.raiz)

print("postorden:")
postorden(arbol.raiz)

print("inorden:")
inorder(arbol.raiz)
