class Nodo:
    def __init__(self, valor):
        self.valor = valor
        self.izquierda = None
        self.derecha = None

class BST:
    def __init__(self):
        self.raiz = None

    def insert(self, data):
        if not self.raiz:
            self.raiz = Nodo(data)
        else:
            self._insert(data, self.raiz)

    def _insert(self, data, nodo_actual):
        if data < nodo_actual.valor:
            if not nodo_actual.izquierda:
                nodo_actual.izquierda = Nodo(data)
            else:
                self._insert(data, nodo_actual.izquierda)
        elif data > nodo_actual.valor:
            if not nodo_actual.derecha:
                nodo_actual.derecha = Nodo(data)
            else:
                self._insert(data, nodo_actual.derecha)
            
    def obtener_altura(self, nodo):
        if not nodo:
            return 0
        return nodo.altura
    
    def Nodo_Presente(self,raiz,Nodo):
        if raiz is None:
            return False
        
        if raiz == Nodo:
            return True
        return self.Nodo_Presente(raiz.izquierda, Nodo) or self.Nodo_Presente(raiz.derecha, Nodo)
    
    def getMin(self):
        #encuentra el nodo que está más a la izquierda
        n = self
        while n.izquierda is not None:
            n = n.izquierda
        return n.valor

    def getMax(self):
        #encuentra el nodo que está más a la derecha
        n = self
        while n.derecha is not None:
            n = n.derecha
        return n.derecha
    
#pagina de ayuda http://www.tugurium.com/python/index.php?C=PYTHON.20_5