class Nodo:
    def __init__(self, valor):
        self.valor = valor
        self.izquierda = None
        self.derecha = None

def encontrar_ancestro_comun(raiz, nodo1, nodo2):
    #se encuentra el ancestro comun de manera recursiva
    #donde hay validaciones es para encontrar rapidamente este ancestro comun
    if raiz is None:
        return None
    if raiz == nodo1 or raiz == nodo2:
        return raiz
    
    izquierda = encontrar_ancestro_comun(raiz.izquierda, nodo1, nodo2)
    derecha = encontrar_ancestro_comun(raiz.derecha, nodo1, nodo2)
    
    if izquierda is not None and derecha is not None:
        return raiz
    
    if izquierda is None:
        return derecha
    else:
        return izquierda

#teniendo en cuenta que las letras del abecedario son numeros
#ej: a = 1, b = 2, c = 3, d = 4... l=12
if __name__ == '__main__':
    raiz = Nodo(1)
    raiz.izquierda = Nodo(2)
    raiz.derecha = Nodo(3)
    raiz.izquierda.izquierda = Nodo(4)
    raiz.izquierda.derecha = Nodo(5)
    raiz.derecha.izquierda = Nodo(6)
    raiz.derecha.derecha = Nodo(7)
    raiz.izquierda.izquierda.izquierda = Nodo (8)
    raiz.izquierda.izquierda.derecha = Nodo(9)
    raiz.izquierda.derecha.izquierda = Nodo(10)
    raiz.izquierda.derecha.derecha = Nodo(11)
    raiz.derecha.izquierda.izquierda = Nodo(12)
    
    nodoH = raiz.izquierda.izquierda.izquierda
    nodoI = raiz.izquierda.izquierda.derecha

    ancestro_comun = encontrar_ancestro_comun(raiz, nodoH, nodoI)
    print("El ancestro común más alto es el nodo con valor:", ancestro_comun.valor)

#ayuda: https://www.techiedelight.com/
#una de las validaciones de la linea 18 a la 24 fueron verificadas por medio de una IA